

# Exercício

1. Criar conta no GitHub (github.com)

2. Criar um repositório público: frontend

3. Clonar o repostório criado, exemplo: 
> git clone https://github.com/cavalcantemmarcelo/curso-frontend.git

4. Adicionar seus arquivos (precisa copiar todos os seus arquivos do curso, exceto os .zip)
> git add *

5. Comitar seu código
> git commit -m 'commit inicial'

6. Subir as alterações
> git push

6. Enviar o link para seu repositório criado na plataforma da EBAC, exemplo:
https://github.com/cavalcantemmarcelo/curso-frontend

7. DESAFIO: criar apresentação pessoal no GitHub
Dica: você precisa criar um repositório com mesmo nome do seu usuário e adicionar o arquivo readme.md =)